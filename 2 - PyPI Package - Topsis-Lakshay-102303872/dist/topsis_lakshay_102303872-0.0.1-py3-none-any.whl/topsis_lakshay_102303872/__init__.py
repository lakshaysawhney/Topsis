from .topsis import topsis
__version__ = "0.0.1"